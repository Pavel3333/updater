import json
import BigWorld
import Math
import Keys
from gui import InputHandler
from Avatar import PlayerAvatar
from gui.shared import EVENT_BUS_SCOPE, events, g_eventBus
from gui.Scaleform.genConsts.BATTLE_VIEW_ALIASES import BATTLE_VIEW_ALIASES

from os import makedirs
from os.path import exists
from functools import partial

class CollisionChecker():
    FOLLOW_POSITION = True
    
    def __init__(self):
        print '[CollisionChecker] init...'
        
        self.desc = {
            'udes_03' : {
                'root_folder': 'vehicles/sweden/S21_UDES_03/normal/lod0/',
                'chassis'    : 'Chassis.model',
                'hull'       : 'Hull.model',
                'turret'     : 'Turret_01.model',
                'gun'        : 'Gun_02.model'
            },
            'rhm.pzw' : {
                'root_folder': 'vehicles/german/G125_Spz_57_Rh/normal/lod0/',
                'chassis'    : 'Chassis.model',
                'hull'       : 'Hull.model',
                'turret'     : 'Turret_01.model',
                'gun'        : 'Gun_02.model'
            },
            'pz.1C' : {
                'root_folder': 'vehicles/german/G63_PzI_ausf_C/normal/lod0/',
                'chassis'    : 'Chassis.model',
                'hull'       : 'Hull.model',
                'turret'     : 'Turret_02.model',
                'gun'        : 'Gun_06.model'
            },
            'is_7' : {
                'root_folder': 'vehicles/russian/R45_IS-7/normal/lod0/',
                'chassis'    : 'Chassis.model',
                'hull'       : 'Hull.model',
                'turret'     : 'Turret_01.model',
                'gun'        : 'Gun_01.model'
            },
            'ball' : {
                'path' : 'objects/misc/bbox/sphere1.model'
            }
        }
        
        self.models = {
            'udes_03': [],
            'rhm.pzw': [],
            'pz.1C'  : [],
            'is_7'   : [],
            'ball'   : []
        }
        
        self.coords = {
            'udes_03': [],
            'rhm.pzw': [],
            'pz.1C'  : [],
            'is_7'   : [],
            'ball'   : []
        }
        
        self.vehUpdCBID = None
        
        self.map_ = ''
        
        self.config_path = './mods/configs/RAINN_VOD/CollisionChecker/CollisionChecker.json'
        
        self.config = {}
        
        if exists(self.config_path):
            self.config = json.loads(open(self.config_path, 'r').read())
        else:
            working_directory = self.config_path[:self.config_path.rfind('/')]
            
            if not exists(working_directory):
                makedirs(working_directory)
            
            open(self.config_path, 'w').write('{}')
        
        g_eventBus.addListener(events.ComponentEvent.COMPONENT_REGISTERED, self.onComponentRegistered, EVENT_BUS_SCOPE.GLOBAL)
    
    def clearModels(self):
        for desc in self.models:
            for models in self.models[desc]:
                BigWorld.delModel(models['main'])
        
        self.models = {
            'udes_03': [],
            'rhm.pzw': [],
            'pz.1C'  : [],
            'is_7'   : [],
            'ball'   : []
        }
    
    def onComponentRegistered(self, event):
        if event.alias == BATTLE_VIEW_ALIASES.CROSSHAIR_PANEL:
            self.battleLoading()
    
    def battleLoading(self):
        self.clearModels()
        
        InputHandler.g_instance.onKeyDown += self.inject_handle_key_event
        self.map_ = BigWorld.player().arena.arenaType.geometryName
        self.createModels()
    
    def battleStop(self):
        InputHandler.g_instance.onKeyDown -= self.inject_handle_key_event
        open(self.config_path, 'w').write(json.dumps(self.config, indent=4, sort_keys=True))
        self.clearModels()
        
        self.map_ = ''
        
        if self.vehUpdCBID is not None:
            BigWorld.cancelCallback(self.vehUpdCBID)
            self.vehUpdCBID = None
    
    def inject_handle_key_event(self, event):
        #if event.isAltDown():
        #print '[CollisionChecker] Alt pressed'
        if event.key == Keys.KEY_NUMPAD1:   #NUM1
            self.createCustomModel(0)
        elif event.key == Keys.KEY_NUMPAD2: #NUM2
            self.createCustomModel(1)
        elif event.key == Keys.KEY_NUMPAD3: #NUM3
            self.createCustomModel(2)
        elif event.key == Keys.KEY_NUMPAD4: #NUM4
            self.createCustomModel(3)
        elif event.key == Keys.KEY_NUMPAD5: #NUM5
            self.createCustomModel(4)
        #else:
        elif event.key == Keys.KEY_DELETE: #DELETE
            print '[CollisionChecker] Del pressed'
            self.delLastModel()
    
    def createModels(self):
        if self.map_ in self.config:
            for signType in self.config[self.map_]:
                for model in self.config[self.map_][signType]:
                    self.createModel(int(signType), tuple(model[0]))
        self.vehUpdater()
    
    def getDist(self, extendedOut):
        pos = None
        camera = BigWorld.camera()
        player = BigWorld.player()
        
        if player is not None and player.vehicle is not None:
            print '[CollisionChecker] getDist - trying to get vehicle pos'
            pos = player.vehicle.model.position
        if not pos and camera is not None:
            print '[CollisionChecker] getDist - trying to get camera pos'
            pos = camera.position
        if not pos:
            print '[CollisionChecker] getDist - pos is not defined!'
            return None
        
        pos = Math.Vector3(pos)
        dist = -1.0
        modelLast = -1
        modelTypeLast = -1
        if self.map_ in self.config:
            cfg_map = self.config[self.map_]
            
            for modelType in cfg_map:
                MT = cfg_map[str(modelType)]
                
                for index in xrange(len(MT)):
                    distTemp = pos.distTo(Math.Vector3(tuple(MT[index][0])))
                    if dist == -1.0 or distTemp < dist:
                        dist = distTemp
                        modelLast = index
                        modelTypeLast = int(modelType)

            if dist != -1.0 and modelLast != -1 and modelTypeLast != -1:
                if extendedOut:
                    return (modelTypeLast, modelLast, dist)
                else:
                    return (modelTypeLast, modelLast)
        return None
    
    def delLastModel(self):
        last = self.getDist(False)
        
        if last is not None:
            del self.config[self.map_][str(last[0])][last[1]]
            
            self.clearModels()
            self.createModels()
            
            return last[0]
        return None
    
    def delLastModelByDist(self, dist):
        last = self.getDist(True)
        
        if last is not None:
            #print 'dist:',     dist
            #print 'distLast:', last[2]
            
            if last[2] > dist:  #If the nearest object is farther than the specified distance
                #print 'farther'
                return None 
            else:               #If the nearest object is closer than the specified distance
                #print 'closer'
                
                modelType  = last[0]
                modelIndex = last[1]
                
                desc = self.desc.keys()[modelType]
                
                del self.config[self.map_][str(modelType)][modelIndex]
                
                BigWorld.delModel(self.models[desc][modelIndex]['main'])
                
                del self.models[desc][modelIndex]
                del self.coords[desc][modelIndex]
                
                return modelType
        return None
    
    def getNode(self, model, nodeName, matrix=None):
        node = None
        try:
            if matrix is None:
                node = model.node(nodeName)
            else:
                node = model.node(nodeName, matrix)
            return node
        except Exception:
            return None

    def collideTerrainOnly(self, start, direction):
        testResTerrain = BigWorld.wg_collideSegment(
            BigWorld.player().spaceID,
            start,
            start + direction.scale(10000.0),
            0,
            0
        )
        if not testResTerrain:
            return None
        
        print '[CollisionChecker] testResTerrain.normal', testResTerrain.normal
        print '[CollisionChecker] dot(1, 0, 0)',          testResTerrain.normal.dot(Math.Vector3(1.0, 0.0, 0.0))
        print '[CollisionChecker] dot(0, 1, 0)',          testResTerrain.normal.dot(Math.Vector3(0.0, 1.0, 0.0))
        print '[CollisionChecker] dot(0, 0, 1)',          testResTerrain.normal.dot(Math.Vector3(0.0, 0.0, 1.0))
        print '[CollisionChecker] dir', dir(testResTerrain.normal)
        
        return testResTerrain.closestPoint
    
    def createCustomModel(self, signType):
        camera = BigWorld.camera()
        player = BigWorld.player()
        
        vehicle    = player.vehicle
        gunRotator = player.gunRotator
        
        pos = self.collideTerrainOnly(Math.Vector3(camera.position), Math.Vector3(camera.direction))
        if pos is None:
            print '[CollisionChecker] createCustomModel - trying to get marker pos'
            marker = gunRotator.markerInfo
            if marker:
                pos = marker[0] 
        if pos is None:
            print '[CollisionChecker] createCustomModel - trying to get vehicle pos'
            pos = vehicle.model.position
        if pos is None:
            print '[CollisionChecker] createCustomModel - pos is not defined!'
            return
        
        self.createModel(signType, pos, True)
    
    def vehUpdater(self):
        player = BigWorld.player()
        if player is not None:
            vehicle = player.vehicle
            if vehicle is not None:
                for desc in self.models:
                    for model in self.models[desc]:
                        chassis_model = model['main']
                        
                        if self.FOLLOW_POSITION and 'pos_start' in model and 'veh_pos_start' in model:
                            pos_start     = Math.Vector3(model['pos_start'])
                            veh_pos_start = Math.Vector3(model['veh_pos_start'])
                            veh_pos       = Math.Vector3(vehicle.model.position)
                            chassis_model.position = veh_pos - veh_pos_start + pos_start
                        #chassis_model.rotate(vehicle.pitch, (1.0, 0.0, 0.0))
                        chassis_model.yaw = vehicle.yaw
                        #chassis_model.rotate(vehicle.roll,  (0.0, 0.0, 1.0))
                        #matrix.setRotateYPR((vehicle.yaw, vehicle.pitch, vehicle.roll))
        
        self.vehUpdCBID = BigWorld.callback(0.0, self.vehUpdater)
    
    def createModel(self, signType, pos, isCustom=False):
        player = BigWorld.player()
        
        vehicle    = player.vehicle
        gunRotator = player.gunRotator
        
        turret_matrix = None
        gun_matrix    = None
        
        if gunRotator:
            turret_matrix = gunRotator.turretMatrix
            gun_matrix    = gunRotator.gunMatrix
        
        desc = self.desc.keys()[signType]
        
        if isCustom:
            print '[CollisionChecker] creating %s model on position %s...' % (desc, pos)
        
        desc_paths = self.desc[desc]

        if 'path' in desc_paths:
            model = BigWorld.Model(desc_paths['path'])
            model.position = pos
            BigWorld.addModel(model)

            self.models[desc].append({
                'main' : model
            })
        else:
            chassis = BigWorld.Model(desc_paths['root_folder'] + desc_paths['chassis'])
            chassis.position = pos
            BigWorld.addModel(chassis)
            
            hull_node = self.getNode(chassis, 'V')
            if hull_node is None:
                print '[CollisionChecker] could not find V node in chassis'
                BigWorld.delModel(chassis)
                return
            
            hull = BigWorld.Model(desc_paths['root_folder'] + desc_paths['hull'])
            hull_node.attach(hull)
            
            turret_node = self.getNode(hull,'HP_turretJoint', turret_matrix)
            if turret_node is None:
                print '[CollisionChecker] could not find HP_turretJoint node in hull'
                BigWorld.delModel(chassis)
                return
            
            turret = BigWorld.Model(desc_paths['root_folder'] + desc_paths['turret'])
            turret_node.attach(turret)
            
            gun_node = self.getNode(turret, 'HP_gunJoint', gun_matrix)
            if gun_node is None:
                print '[CollisionChecker] could not find HP_gunJoint node in turret'
                BigWorld.delModel(chassis)
                return
            
            gun = BigWorld.Model(desc_paths['root_folder'] + desc_paths['gun'])
            gun_node.attach(gun)
            
            self.models[desc].append({
                'pos_start'    : tuple(pos),
                'veh_pos_start': vehicle.model.position,
                'main'         : chassis,
                'hull'         : hull,
                'turret'       : turret,
                'gun'          : gun
            })
        self.coords[desc].append(pos)
        
        if isCustom:
            signType_s = str(signType)
            
            if self.map_ not in self.config:
                self.config[self.map_] = {signType_s: []}
            
            if signType_s not in self.config[self.map_]:
                self.config[self.map_][signType_s] = []
                
            self.config[self.map_][signType_s].append([list(pos)])

collisionChecker = CollisionChecker()
hookExit = PlayerAvatar._PlayerAvatar__destroyGUI

def hookedExit(self, *args):
    collisionChecker.battleStop()
    hookExit(self, *args)


PlayerAvatar._PlayerAvatar__destroyGUI = hookedExit
