# This file was created automatically from build script
__xvm_version__ = '8.3.2'
__wot_version__ = '1.8.0.0'
__revision__ = '30'
__branch__ = 'master'
__node__ = '28fa3fcbb8be1a410582caf1d7fe97bf365e3a67'
__development__ = 'True'
