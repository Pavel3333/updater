import BigWorld
from Math import Matrix

from gui.Scaleform.framework import ViewTypes
from ids_generators import SequenceIDGenerator

from helpers import dependency
from skeletons.gui.app_loader import IAppLoader

class _Entry(object):
    @staticmethod
    def _minimapComponent():
        g_appLoader = dependency.instance(IAppLoader)
        
        try: return g_appLoader.getDefBattleApp().containerManager.getContainer(ViewTypes.VIEW).getView().components['minimap']
        except: pass

    def __init__(self, symbol, container, matrix, active, transform_props):
        self.__handle = self._minimapComponent().addEntry(symbol, container, matrix, active, transform_props)
    
    def getID(self):
        return self.__handle
    
    def invoke(self, name, *args):
        if args:
            signature = (name, list(args))
        else:
            signature = (name,)
        return self._minimapComponent().invoke(self.__handle, name, *args)

    def setMatrix(self, matrix):
        return self._minimapComponent().setMatrix(self.__handle, matrix)

    def __del__(self):
        try: return self._minimapComponent().delEntry(self.__handle)
        except: pass

class _EntryManager(object):
    entries = property(lambda self: self.__entries)
    
    def __init__(self):
        self.__entries = {}

    def hasEntry(self, key):
        return key in self.__entries.keys()

    def addEntry(self, key, symbol, container, matrix, active = True, transform_props = 4294967295L):
        self.__entries[key] = _Entry(symbol, container, matrix, active, transform_props)

    def delEntry(self, key):
        if self.hasEntry(key):
            del self.__entries[key]

    def setMatrix(self, key, matrix):
        if self.hasEntry(key):
            return self.__entries[key].setMatrix(matrix)

    def getEntry(self, key):
        if self.hasEntry(key):
            return self.__entries[key]

    def invokeEntry(self, key, *a, **k):
        if self.hasEntry(key):
            return self.__entries[key].invoke(*a, **k)

    def clear(self):
        return self.__entries.clear()

class Minimap:
    def __init__(self):
        self.posCounter = 0
        
        self.idGen = SequenceIDGenerator()
        self.minimapEntries = _EntryManager()
    
    def createMinimapPoints(self, poses, markerType):
        self.posCounter = len(poses)
        
        for i in xrange(self.posCounter):
            if not poses[i]:
                continue
            
            newmatrix = Matrix()
            newmatrix.setTranslate(poses[i])
            
            itemID = self.idGen.next()
            
            self.minimapEntries.addEntry(itemID, 'PositionsItemEntry', 'icons', newmatrix) #PositionsItemEntry
            self.minimapEntries.invokeEntry(itemID, 'setIcon', markerType) #setImage
            

    def getMarkers(self):
        g_appLoader = dependency.instance(IAppLoader)
        
        try: return g_appLoader.getDefBattleApp().containerManager.getContainer(ViewTypes.DEFAULT).getView()._external[1]
        except: return None
    
    def callMarkers(self, func, *args):
        markersManager = self.getMarkers()
        if markersManager is not None:
            try:
                func = getattr(markersManager, func, None)
                if func is not None:
                    return func(*args)
            except:
                return -1
    
    def delMarkers(self):
        for i in range(self.posCounter):
            self.minimapEntries.delEntry(i)
        
        self.minimapEntries.clear()

#hook

from os.path import exists
from gui.Scaleform.battle_entry import BattleEntry

def hooked_getRequiredLibraries(base, self, *args):
    result = base(self, *args)
    
    path = 'res_mods/mods/xfw_packages/PositionsMod_TEST/native_32bit/coloredSigns.swf'
    
    if exists('../' + path):
        result += ('../../../' + path, )
    else:
        print 'PositionsMod_TEST: flash is not exists'
    
    return result

old_getRequiredLibraries = BattleEntry._getRequiredLibraries
BattleEntry._getRequiredLibraries = lambda self, *args: hooked_getRequiredLibraries(old_getRequiredLibraries, self, *args)