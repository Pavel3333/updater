import AnimationSequence
import BigWorld
import Math
import Keys
from gui import InputHandler
from Avatar import PlayerAvatar
from gui.shared import EVENT_BUS_SCOPE, events, g_eventBus
from gui.Scaleform.genConsts.BATTLE_VIEW_ALIASES import BATTLE_VIEW_ALIASES
from Math import Matrix
from gui.Scaleform.daapi.view.battle.shared.minimap.common import EntriesPlugin
from gui.Scaleform.daapi.view.battle.shared.minimap.component import MinimapPluginsCollection
from gui.Scaleform.genConsts.BATTLE_VIEW_ALIASES import BATTLE_VIEW_ALIASES
from gui.shared import EVENT_BUS_SCOPE, events, g_eventBus
from tutorial.control.battle.functional import _StaticMinimapMarker2D

import json

import Minimap

class AnimatedModel():
    def __init__(self, path, action, position):
        self.__path   = path
        self.__action = action
        
        self.__position = Math.Vector3((position[0], position[1], position[2]))#Math.Vector3((position[0], position[1] + 5.0, position[2]))
        
        self.model      = None
        self.__animator = None
        
        if self.__path is not None:
            BigWorld.fetchModel(self.__path, self.__onModelLoaded)
    
    def __del__(self):
        self.__path   = None
        self.__action = None
        
        self.__position = None
        
        if self.model:
            BigWorld.delModel(self.model)
            self.model = None
        
        self.__animator = None
    
    def __onModelLoaded(self, model):
        if not model:
            return
        
        self.model = model
        self.model.position = self.__position
        self.model.castsShadow = False
        
        BigWorld.addModel(self.model)
        
        if not self.__action:
            return
        
        clipResource = self.model.deprecatedGetAnimationClipResource(self.__action)
        
        spaceID = BigWorld.player().spaceID
        loader = AnimationSequence.Loader(clipResource, spaceID)
        self.__animator = loader.loadSync()
        self.__animator.bindTo(AnimationSequence.ModelWrapperContainer(self.model, spaceID))
        self.__animator.start()

class Positions:
    def __init__(self):
        self.animatedModels = []
        self.lights = []
        self.markers = {
            'green' : [],
            'yellow': [],
            'red'   : []
        }
        
        self.ho = 0.0
        
        self.path = 'objects/pavel3333_positions/new_models/sign%s.model'#'objects/pavel3333_positions/models/lod0/sign%s.model'
        self.height_offset = 0.0
        self.config = json.loads(open('../mods/configs/PositionsMod/positions.json', 'r').read())
        g_eventBus.addListener(events.ComponentEvent.COMPONENT_REGISTERED, self.onComponentRegistered, EVENT_BUS_SCOPE.GLOBAL)

    def onComponentRegistered(self, event):
        if event.alias == BATTLE_VIEW_ALIASES.CROSSHAIR_PANEL:
            self.battleLoading()

    def battleLoading(self):
        InputHandler.g_instance.onKeyDown += self.inject_handle_key_event
        
        player = BigWorld.player()
        map_ = player.arena.arenaType.geometryName
        
        #if not NEW_MODELS:
        #    typeDescriptor = player.vehicle.typeDescriptor
        #    bbox_hull = typeDescriptor.hull.hitTester.bbox
        #    bbox_turret = typeDescriptor.turret.hitTester.bbox
        #    if bbox_hull is not None and bbox_turret is not None:
        #        self.height_offset = 1.0 + bbox_hull[1][1] - bbox_hull[0][1] + bbox_turret[1][1] - bbox_turret[0][1]
        #else:
        self.height_offset = 0.0
        
        self.createModels(map_)
        
        for key in self.markers:
            markers.createMinimapPoints(self.markers[key], key)

    def battleStop(self):
        InputHandler.g_instance.onKeyDown -= self.inject_handle_key_event
        open('../mods/configs/PositionsMod/positions.json', 'w').write(json.dumps(self.config, indent=4, sort_keys=True))
        self.deleteModels()
        self.markers = {
            'green' : [],
            'yellow': [],
            'red'   : []
        }

    def inject_handle_key_event(self, event):
        player = BigWorld.player()
        
        if not player._PlayerAvatar__forcedGuiCtrlModeFlags:
            if event.key == Keys.KEY_NUMPAD1:
                self.createCustomModel(1)
            if event.key == Keys.KEY_NUMPAD2:
                self.createCustomModel(2)
            if event.key == Keys.KEY_NUMPAD3:
                self.createCustomModel(3)
            if event.key == Keys.KEY_NUMPAD4:
                self.ho += 0.1
                for model in self.animatedModels:
                    if model.model:
                        pos = model.model.position
                        pos[1] += 0.1
                        model.model.position = pos
                print 'offset:', self.ho
            if event.key == Keys.KEY_NUMPAD5:
                self.ho -= 0.1
                for model in self.animatedModels:
                    if model.model:
                        pos = model.model.position
                        pos[1] -= 0.1
                        model.model.position = pos
                print 'offset:', self.ho
            if event.key == Keys.KEY_N:
                for light in self.lights:
                    light.multiplier *= 2
                    print 'multiplier:', light.multiplier

            if event.key == Keys.KEY_DELETE:
                self.delLastModel()
            if event.key == Keys.KEY_B:
                for light in self.lights:
                    light.multiplier = light.multiplier / 2
                    print 'multiplier:', light.multiplier

    def createModels(self, map_):
        if map_ in self.config:
            for signType in self.config[map_]:
                for veh_pos in self.config[map_][signType]:
                    self.createModel(int(signType), veh_pos)
                    
                    signDesc = 'yellow'
                    if signType == u'2':
                        signDesc = 'green'
                    elif signType == u'3':
                        signDesc = 'red'
                    self.markers[signDesc].append(tuple(veh_pos))

    def createLight(self, pos, signType):
        colour = (255, 255, 0, 0)
        if signType == 2:
            colour = (0, 255, 0, 0)
        elif signType == 3:
            colour = (255, 0, 0, 0)
        pos_light = (pos[0], pos[1] + 0.5, pos[2])
        light = BigWorld.PyOmniLight()
        light.innerRadius = 1
        light.outerRadius = 10
        light.multiplier = 500.0
        light.position = pos_light
        light.colour = colour
        self.lights.append(light)

    def delLastModel(self):
        player = BigWorld.player()
        if player is None:
            return
        else:
            map_ = player.arena.arenaType.geometryName
            pos = Math.Vector3(player.vehicle.model.position)
            dist = -1.0
            modelLast = -1
            modelTypeLast = -1
            if map_ in self.config:
                for modelType in self.config[map_]:
                    for index in xrange(len(self.config[map_][modelType])):
                        distTemp = pos.distTo(Math.Vector3(tuple(self.config[map_][modelType][index])))
                        if dist == -1.0 or distTemp < dist:
                            dist = distTemp
                            modelLast = index
                            modelTypeLast = modelType

            if dist != -1.0 and modelLast != -1 and modelTypeLast != -1:
                del self.config[map_][modelTypeLast][modelLast]
                self.deleteModels()
                self.createModels(map_)
                markers.delMarkers()
                
            for key in self.markers:
                markers.createMinimapPoints(self.markers[key], key)

    def createCustomModel(self, signType):
        veh_pos = BigWorld.player().vehicle.model.position
        self.createModel(signType, veh_pos, True)

    def createModel(self, signType, veh_pos, isCustom=False):
        if isCustom:
            signDesc = 'firing'
            if signType == 2:
                signDesc = 'lighting'
            elif signType == 3:
                signDesc = 'LFD'
            print 'creating %s model on position %s...' % (signDesc, veh_pos)
        pos = (veh_pos[0], veh_pos[1] + self.height_offset, veh_pos[2])
        #self.createLight(pos, signType)
        
        self.animatedModels.append(
            AnimatedModel(self.path % signType, 'rotation', pos)
        )
        
        if isCustom:
            signType_s = str(signType)
            map_ = BigWorld.player().arena.arenaType.geometryName
            if map_ not in self.config:
                self.config[map_] = {signType_s: []}
            if signType_s not in self.config[map_]:
                self.config[map_][signType_s] = []
            self.config[map_][signType_s].append(list(veh_pos))

    def deleteModels(self):
        for animatedModel in self.animatedModels:
            del animatedModel
        
        self.animatedModels = []
        
        for light in self.lights:
            light.destroyLight()
        
        self.lights = []


positions = Positions()
markers = Minimap.Minimap()
hookExit = PlayerAvatar._PlayerAvatar__destroyGUI

def hookedExit(self, *args):
    positions.battleStop()
    hookExit(self, *args)


PlayerAvatar._PlayerAvatar__destroyGUI = hookedExit