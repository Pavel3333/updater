import json
import BigWorld
import Math
import Keys
from gui import InputHandler
from gui.shared import EVENT_BUS_SCOPE, events, g_eventBus
from gui.Scaleform.genConsts.BATTLE_VIEW_ALIASES import BATTLE_VIEW_ALIASES

from os import makedirs
from os.path import exists
from functools import partial

class CollisionChecker():
    def __init__(self):
        print '[CollisionChecker] init...'
        
        self.enabled = False
        
        self.desc = {
            'ball' : {
                'path' : 'objects/misc/bbox/sphere1.model'
            }
        }
        
        self.models = {
            'ball'   : []
        }
        
        self.coords = {
            'ball' : []
        }
        
        self.map_ = ''
        
        self.config_path = './mods/configs/RAINN_VOD/CollisionChecker/CollisionChecker.json'
        
        self.config = {}
        
        if exists(self.config_path):
            self.config = json.loads(open(self.config_path, 'r').read())
        else:
            working_directory = self.config_path[:self.config_path.rfind('/')]
            
            if not exists(working_directory):
                makedirs(working_directory)
            
            open(self.config_path, 'w').write('{}')
        
        g_eventBus.addListener(events.ComponentEvent.COMPONENT_REGISTERED, self.onComponentRegistered, EVENT_BUS_SCOPE.GLOBAL)
    
    def clearModels(self):
        for desc in self.models:
            for models in self.models[desc]:
                BigWorld.delModel(models['main'])
        
        self.models = {
            'ball'   : []
        }
    
    def onComponentRegistered(self, event):
        if event.alias == BATTLE_VIEW_ALIASES.CROSSHAIR_PANEL:
            self.battleLoading()
    
    def battleLoading(self):
        self.clearModels()
        
        InputHandler.g_instance.onKeyDown += self.inject_handle_key_event
        self.map_ = BigWorld.player().arena.arenaType.geometryName
        self.enabled = True
        self.createModels()
    
    def battleStop(self):
        InputHandler.g_instance.onKeyDown -= self.inject_handle_key_event
        open(self.config_path, 'w').write(json.dumps(self.config, indent=4, sort_keys=True))
        self.enabled = False
        self.clearModels()
        
        self.map_ = ''
    
    def inject_handle_key_event(self, event):
        #if event.isAltDown():
        #print '[CollisionChecker] Alt pressed'
        if event.key == Keys.KEY_NUMPAD1:   # NUM1
            self.createCustomModel(0)
        elif event.key == Keys.KEY_K:       # K
            self.enabled = not self.enabled
            
            self.clearModels()
            if self.enabled:
                self.createModels()
        elif event.key == Keys.KEY_DELETE:  #DELETE
            self.delLastModel()
    
    def createModels(self):
        if self.map_ in self.config:
            for signType in self.config[self.map_]:
                for model in self.config[self.map_][signType]:
                    self.createModel(int(signType), tuple(model[0]))
    
    def getDist(self, extendedOut):
        pos = None
        camera = BigWorld.camera()
        player = BigWorld.player()
        
        if player is not None and player.vehicle is not None:
            pos = player.vehicle.model.position
        if not pos and camera is not None:
            pos = camera.position
        if not pos:
            print '[CollisionChecker] getDist - pos is not defined!'
            return None
        
        pos = Math.Vector3(pos)
        dist = -1.0
        modelLast = -1
        modelTypeLast = -1
        if self.map_ in self.config:
            cfg_map = self.config[self.map_]
            
            for modelType in cfg_map:
                MT = cfg_map[str(modelType)]
                
                for index in xrange(len(MT)):
                    distTemp = pos.distTo(Math.Vector3(tuple(MT[index][0])))
                    if dist == -1.0 or distTemp < dist:
                        dist = distTemp
                        modelLast = index
                        modelTypeLast = int(modelType)

            if dist != -1.0 and modelLast != -1 and modelTypeLast != -1:
                if extendedOut:
                    return (modelTypeLast, modelLast, dist)
                else:
                    return (modelTypeLast, modelLast)
        return None
    
    def delLastModel(self):
        last = self.getDist(False)
        
        if last is not None:
            del self.config[self.map_][str(last[0])][last[1]]
            
            self.clearModels()
            self.createModels()
            
            return last[0]
        return None
    
    def delLastModelByDist(self, dist):
        last = self.getDist(True)
        
        if last is not None:
            
            if last[2] > dist:  #If the nearest object is farther than the specified distance
                return None 
            else:               #If the nearest object is closer than the specified distance
                
                modelType  = last[0]
                modelIndex = last[1]
                
                desc = self.desc.keys()[modelType]
                
                del self.config[self.map_][str(modelType)][modelIndex]
                
                BigWorld.delModel(self.models[desc][modelIndex]['main'])
                
                del self.models[desc][modelIndex]
                del self.coords[desc][modelIndex]
                
                return modelType
        return None
    
    def getNode(self, model, nodeName, matrix=None):
        node = None
        try:
            if matrix is None:
                node = model.node(nodeName)
            else:
                node = model.node(nodeName, matrix)
            return node
        except Exception:
            return None

    def collideTerrainOnly(self, start, direction):
        testResTerrain = BigWorld.wg_collideSegment(
            BigWorld.player().spaceID,
            start,
            start + direction.scale(10000.0),
            0,
            0
        )
        if not testResTerrain:
            return None
        
        return testResTerrain.closestPoint
    
    def createCustomModel(self, signType):
        camera = BigWorld.camera()
        player = BigWorld.player()
        
        vehicle    = player.vehicle
        gunRotator = player.gunRotator
        
        pos = self.collideTerrainOnly(Math.Vector3(camera.position), Math.Vector3(camera.direction))
        if pos is None:
            marker = gunRotator.markerInfo
            if marker:
                pos = marker[0] 
        if pos is None:
            pos = vehicle.model.position
        if pos is None:
            print '[CollisionChecker] createCustomModel - pos is not defined!'
            return
        
        self.createModel(signType, pos, True)
    
    def createModel(self, signType, pos, isCustom=False):
        vehicle = BigWorld.player().vehicle
        
        desc = self.desc.keys()[signType]
        
        desc_paths = self.desc[desc]
        
        if 'path' in desc_paths:
            model = BigWorld.Model(desc_paths['path'])
            model.position = pos
            BigWorld.addModel(model)
        
            self.models[desc].append({
                'main' : model
            })
        self.coords[desc].append(pos)
        
        if isCustom:
            signType_s = str(signType)
            
            if self.map_ not in self.config:
                self.config[self.map_] = {signType_s: []}
            
            if signType_s not in self.config[self.map_]:
                self.config[self.map_][signType_s] = []
                
            self.config[self.map_][signType_s].append([list(pos)])

collisionChecker = CollisionChecker()
