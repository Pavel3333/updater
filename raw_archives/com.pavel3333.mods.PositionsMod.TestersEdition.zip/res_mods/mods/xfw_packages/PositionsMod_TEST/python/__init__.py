import AnimationSequence
import BigWorld
import Math
import Keys
from gui import InputHandler
from Avatar import PlayerAvatar
from gui.shared import EVENT_BUS_SCOPE, events, g_eventBus
from gui.Scaleform.genConsts.BATTLE_VIEW_ALIASES import BATTLE_VIEW_ALIASES
from Math import Matrix
from gui.Scaleform.daapi.view.battle.shared.minimap.common import EntriesPlugin
from gui.Scaleform.daapi.view.battle.shared.minimap.component import MinimapPluginsCollection
from gui.Scaleform.genConsts.BATTLE_VIEW_ALIASES import BATTLE_VIEW_ALIASES
from gui.shared import EVENT_BUS_SCOPE, events, g_eventBus
from tutorial.control.battle.functional import _StaticMinimapMarker2D

import json

import Minimap

class Shared(object):
    CONFIG_PATH = 'mods/configs/PositionsMod/config.json'
    
    def __init__(self):
        self.config = {
            'oldModel'       : False,
            'oldDesign'      : False,
            'createLights'   : True,
            'createByCamera' : False,
            
            'createLightingKey' : 'KEY_NUMPAD1',
            'createFiringKey'   : 'KEY_NUMPAD2',
            'createArmoringKey' : 'KEY_NUMPAD3',
            
            'showOldPositionsKey' : 'KEY_K',
            'showAllPositionsKey' : 'KEY_L',
            
            'deleteLastPositionKey' : 'KEY_DELETE'
        }
        
        self.config.update(self.loadDefaultJSON(self.CONFIG_PATH, self.config))
        
        self.height_offset = 0.0
    
    def loadJSON(self, path):
        try:
            return json.load(open(path, 'r'))
        except IOError:
            return {}
    
    def loadDefaultJSON(self, path, default):
        data = self.loadJSON(path)
        
        if not all(key in data.keys() for key in default.keys()):
            self.dumpJSON(path, default)
            return default
        
        return data
    
    def dumpJSON(self, path, data):
        json.dump(data, open(path, 'w'), sort_keys=True, indent=4)
    
    def checkKey(self, key, default, config_field=None):
        default_key = getattr(Keys, default)
        
        if config_field is None:
            return key == default_key
        
        return key == getattr(Keys, g_Shared.config.get(config_field, default), default_key)

class AnimatedModel(object):
    MODELS_ROOT = 'objects'
    ACTION      = 'rotation'
    
    signType2OldColor = {
        1 : (255, 255, 0, 0),
        2 : (0, 255, 0, 0),
        3 : (255, 0, 0, 0)
    }
    
    signType2NewColor = {
        1 : (255, 255, 0, 0),
        2 : (0, 126, 232, 0),
        3 : (216, 0, 255, 0)
    }
    
    def __init__(self, sign_type, position):
        self.__path  = '%s/%s/%s/sign%s.model'%(
            self.MODELS_ROOT, 
            'pavel3333_positions_old' if g_Shared.config['oldDesign'] else 'pavel3333_positions',
            'models/lod0'             if g_Shared.config['oldModel']  else 'new_models',
            sign_type
        )
        
        self.__action    = self.ACTION
        self.__animator  = None
        
        self.position  = position
        self.sign_type = sign_type
        
        self.model    = None
        self.light    = None
        self.markerID = None
        
        self.createMarker()
        
        if g_Shared.config['createLights']:
            self.createLight()
        
        if self.__path is not None:
            BigWorld.fetchModel(self.__path, self.__onModelLoaded)
    
    def createMarker(self):
        if self.markerID is None:
            self.markerID = g_Markers.createMinimapPoint(
                self.position,
                sign_type=self.sign_type
            )
    
    def deleteMarker(self):
        if self.markerID is not None:
            g_Markers.deleteMarker(self.markerID)
            self.markerID = None
    
    def __del__(self):
        self.deleteMarker()
        
        if self.light is not None:
            self.light.destroyLight()
        
        if self.model is not None:
            BigWorld.delModel(self.model)
    
    def __onModelLoaded(self, model):
        if not model:
            return
        
        position = self.position
        
        self.model          = model
        self.model.position = Math.Vector3((
            position[0],
            position[1] + g_Shared.height_offset,
            position[2]
        ))
        
        self.model.castsShadow = False
        
        BigWorld.addModel(self.model)
        
        if not self.__action:
            return
        
        clip_resource = self.model.deprecatedGetAnimationClipResource(self.__action)
        
        spaceID = BigWorld.player().spaceID
        loader  = AnimationSequence.Loader(clip_resource, spaceID)
        
        self.__animator = loader.loadSync()
        self.__animator.bindTo(AnimationSequence.ModelWrapperContainer(self.model, spaceID))
        self.__animator.start()
    
    def setVisiblity(self, visiblity):
        if self.model is not None:
            self.model.visible = visiblity
        
        if self.light is not None:
            self.light.visible = visiblity
        
        if not visiblity:
            self.deleteMarker()
        else:
            self.createMarker()
    
    def createLight(self):
        position       = self.position
        signType2Color = self.signType2OldColor if g_Shared.config['oldDesign'] else self.signType2NewColor
        
        light             = BigWorld.PyOmniLight()
        light.innerRadius = 1
        light.outerRadius = 10
        light.multiplier  = 500.0
        light.colour      = signType2Color[self.sign_type]
        light.position    = (
            position[0],
            position[1] + 0.5,
            position[2]
        )

class Positions:
    POSITIONS_PATH = 'mods/configs/PositionsMod/positions.json'
    
    def __init__(self):
        self.animated_models = {}
        
        self.is_new_models_showed = False
        self.is_old_models_showed = False
        
        self.clearModels()
        
        self.positions = g_Shared.loadJSON(self.POSITIONS_PATH)
        
        g_eventBus.addListener(events.ComponentEvent.COMPONENT_REGISTERED, self.onComponentRegistered, EVENT_BUS_SCOPE.GLOBAL)
        
        old_destroyGUI = PlayerAvatar._PlayerAvatar__destroyGUI
        PlayerAvatar._PlayerAvatar__destroyGUI = lambda *args: self.hookedExit(old_destroyGUI, *args)
    
    def hookedExit(self, func, *args):
        self.battleStop()
        func(*args)
    
    def _setModelsVisiblity(self, visiblity, model_type):
        if model_type not in self.animated_models:
            return
        
        for model in self.animated_models[model_type]:
            if model.model is not None:
                model.setVisiblity(visiblity)
        
        if model_type == 'new':
            self.is_new_models_showed = visiblity
        else:
            self.is_old_models_showed = visiblity
    
    def setModelsVisiblity(self, visiblity, model_type=None):
        if model_type is not None:
            self._setModelsVisiblity(visiblity, model_type)
            return
        
        for model_type in self.animated_models:
            self._setModelsVisiblity(visiblity, model_type)
    
    def clearModels(self):
        for models in self.animated_models.values():
            for model in models:
                del model
        
        self.animated_models = {
            'old' : [],
            'new' : []
        }
        
        self.is_new_models_showed = False
        self.is_old_models_showed = False
    
    def onComponentRegistered(self, event):
        if event.alias != BATTLE_VIEW_ALIASES.CROSSHAIR_PANEL:
            return
        
        InputHandler.g_instance.onKeyDown += self.inject_handle_key_event
        
        player = BigWorld.player()
        mapID = player.arena.arenaType.geometryName
        
        g_Shared.height_offset = 0.0
        
        if g_Shared.config['oldModel']:
            typeDescriptor = player.vehicle.typeDescriptor
            bbox_hull   = typeDescriptor.hull.hitTester.bbox
            bbox_turret = typeDescriptor.turret.hitTester.bbox
            if bbox_hull is not None and bbox_turret is not None:
                g_Shared.height_offset = 1.0 + bbox_hull[1][1] - bbox_hull[0][1] + bbox_turret[1][1] - bbox_turret[0][1]
        
        self.createModels(mapID)

    def battleStop(self):
        InputHandler.g_instance.onKeyDown -= self.inject_handle_key_event
        
        g_Shared.dumpJSON(self.POSITIONS_PATH, self.positions)
        self.clearModels()

    def inject_handle_key_event(self, event):
        if BigWorld.player()._PlayerAvatar__forcedGuiCtrlModeFlags:
            return
        
        if g_Shared.checkKey(event.key, 'KEY_NUMPAD1', 'createLightingKey'):    # Create lighting position
            self.createCustomModel(1)
        if g_Shared.checkKey(event.key, 'KEY_NUMPAD2', 'createFiringKey'):      # Create firing position
            self.createCustomModel(2)
        if g_Shared.checkKey(event.key, 'KEY_NUMPAD3', 'createArmoringKey'):    # Create armoring position
            self.createCustomModel(3)
        if g_Shared.checkKey(event.key, 'KEY_K', 'showOldPositionsKey'):        # Show/hide new positions
            self.setModelsVisiblity(not self.is_new_models_showed, 'new')
        if g_Shared.checkKey(event.key, 'KEY_L', 'showAllPositionsKey'):        # Show/hide all positions
            showed = self.is_old_models_showed or self.is_new_models_showed
            self.setModelsVisiblity(not showed)
        if g_Shared.checkKey(event.key, 'KEY_DELETE', 'deleteLastPositionKey'): # Delete last position
            self.deleteLastModel()

    def createModels(self, mapID):
        if mapID not in self.positions:
            return
        
        for sign_type, sign_positions in self.positions[mapID].iteritems():
            for position in sign_positions:
                self.createModel(int(sign_type), tuple(position))
    
    def deleteModel(self, mapID, sign_type, index=None, position=None):
        if mapID not in self.positions:
            return
        
        map_positions = self.positions[mapID]
        
        if sign_type not in map_positions:
            return
        
        sign_positions = map_positions[sign_type]
        
        if index is None:
            index = sign_positions.index(position)
        else:
            position = sign_positions[index]
        
        for models in self.animated_models.values():
            for model in models:
                if model.sign_type == int(sign_type) and model.position == tuple(position):
                    models.remove(model)
                    del model
                    break
        
        del sign_positions[index]
    
    def deleteLastModel(self):
        player = BigWorld.player()
        if player is None:
            return
        
        mapID = player.arena.arenaType.geometryName
        if mapID not in self.positions:
            return
        
        src_position = Math.Vector3(player.vehicle.model.position)
        
        last_dist      = None
        last_sign_type = None
        last_index     = None
        
        for sign_type, sign_positions in self.positions[mapID].iteritems():
            for index, dst_position in enumerate(sign_positions):
                new_dist = src_position.distTo(Math.Vector3(tuple(dst_position)))
                if last_dist is None or new_dist < last_dist:
                    last_dist      = new_dist
                    last_sign_type = sign_type
                    last_index     = index
        
        if last_sign_type is not None and last_index is not None:
            self.deleteModel(mapID, last_sign_type, index=last_index)

    def createCustomModel(self, sign_type):
        camera = BigWorld.camera()
        player = BigWorld.player()
        
        vehicle     = player.vehicle
        gun_rotator = player.gunRotator
        
        position = vehicle.model.position
        
        if g_Shared.config['createByCamera']:
            camera_position = self.collideTerrainOnly(Math.Vector3(camera.position), Math.Vector3(camera.direction))
            if camera_position is None:
                marker = gun_rotator.markerInfo
                if marker:
                    camera_position = marker[0]
            if camera_position is not None:
                position = camera_position
        
        self.createModel(sign_type, position, True)
    
    def createModel(self, sign_type, position, is_new=False):
        if is_new:
            signDesc = 'firing'
            if sign_type == 2:
                signDesc = 'lighting'
            elif sign_type == 3:
                signDesc = 'armoring'
            print 'Creating %s model on position %s...' % (signDesc, position)
        
        model_type = 'new' if is_new else 'old'
        
        if is_new and not self.is_new_models_showed or not is_new and not self.is_old_models_showed:
            self.setModelsVisiblity(True, model_type)
        
        self.animated_models[model_type].append(AnimatedModel(sign_type, position))
        
        if not is_new:
            return
        
        sign_type_str = str(sign_type)
        mapID = BigWorld.player().arena.arenaType.geometryName
        
        if mapID not in self.positions:
            self.positions[mapID] = {}
        
        map_positions = self.positions[mapID]
        
        if sign_type_str not in map_positions:
            map_positions[sign_type_str] = []
        
        map_positions[sign_type_str].append(list(position))

g_Shared    = Shared()
g_Positions = Positions()
g_Markers   = Minimap.Minimap()

# Flash

from os.path import exists
from gui.Scaleform.battle_entry import BattleEntry

def hooked_getRequiredLibraries(func, *args):
    result = func(*args)
    
    path = 'res_mods/mods/xfw_packages/PositionsMod_TEST/swf/%s.swf'%('coloredSigns' if not g_Shared.config['oldDesign'] else 'coloredSigns_old')
    
    if exists(path):
        result += ('../../../' + path, )
    else:
        print 'PositionsMod_TEST: flash is not exists'
    
    return result

old_getRequiredLibraries = BattleEntry._getRequiredLibraries
BattleEntry._getRequiredLibraries = lambda *args: hooked_getRequiredLibraries(old_getRequiredLibraries, *args)