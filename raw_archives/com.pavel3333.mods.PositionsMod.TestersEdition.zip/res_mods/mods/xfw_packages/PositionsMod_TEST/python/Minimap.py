import BigWorld

from Math import Matrix

from gui.Scaleform.framework import ViewTypes
from ids_generators import SequenceIDGenerator

from helpers import dependency
from skeletons.gui.app_loader import IAppLoader

class _Entry(object):
    @staticmethod
    def _minimapComponent():
        g_appLoader = dependency.instance(IAppLoader)
        
        try: return g_appLoader.getDefBattleApp().containerManager.getContainer(ViewTypes.VIEW).getView().components['minimap']
        except: pass

    def __init__(self, symbol, container, matrix, active, transform_props):
        self.__handle = self._minimapComponent().addEntry(symbol, container, matrix, active, transform_props)
    
    def getID(self):
        return self.__handle
    
    def invoke(self, name, *args):
        return self._minimapComponent().invoke(self.__handle, name, *args)

    def setMatrix(self, matrix):
        return self._minimapComponent().setMatrix(self.__handle, matrix)

    def __del__(self):
        try: return self._minimapComponent().delEntry(self.__handle)
        except: pass

class _EntryManager(object):
    entries = property(lambda self: self.__entries)
    
    def __init__(self):
        self.__entries = {}

    def hasEntry(self, key):
        return key in self.__entries.keys()

    def addEntry(self, key, symbol, container, matrix, active = True, transform_props = 4294967295L):
        self.__entries[key] = _Entry(symbol, container, matrix, active, transform_props)

    def delEntry(self, key):
        if self.hasEntry(key):
            del self.__entries[key]

    def setMatrix(self, key, matrix):
        if self.hasEntry(key):
            return self.__entries[key].setMatrix(matrix)

    def getEntry(self, key):
        if self.hasEntry(key):
            return self.__entries[key]

    def invokeEntry(self, key, *a, **k):
        if self.hasEntry(key):
            return self.__entries[key].invoke(*a, **k)

    def clear(self):
        return self.__entries.clear()

class Minimap:
    signType2MarkerType = {
            1 : 'yellow',
            2 : 'green',
            3 : 'red'
        }
    
    def __init__(self):
        self.markers = []
        
        self.ID_generator    = SequenceIDGenerator()
        self.minimap_entries = _EntryManager()
    
    def createMinimapPoint(self, position, sign_type=None, marker_type=None):
        if marker_type is None:
            marker_type = self.signType2MarkerType[sign_type]
        
        newmatrix = Matrix()
        newmatrix.setTranslate(position)
        
        itemID = self.ID_generator.next()
        
        self.minimap_entries.addEntry(itemID, 'PositionsItemEntry', 'icons', newmatrix)
        self.minimap_entries.invokeEntry(itemID, 'setIcon', marker_type)
        
        self.markers.append(itemID)
        
        return itemID
    
    def getMarkers(self):
        g_appLoader = dependency.instance(IAppLoader)
        
        try: return g_appLoader.getDefBattleApp().containerManager.getContainer(ViewTypes.DEFAULT).getView()._external[1]
        except: return None
    
    def callMarkers(self, func, *args):
        markers_manager = self.getMarkers()
        if markers_manager is not None:
            try:
                func = getattr(markers_manager, func, None)
                if func is not None:
                    return func(*args)
            except:
                return -1
    
    def deleteMarker(self, itemID):
        if itemID is not None and itemID in self.markers:
            self.markers.remove(itemID)
            self.minimap_entries.delEntry(itemID)
    
    def deleteMarkers(self):
        for itemID in self.markers:
            self.deleteMarker(itemID)
        
        self.minimap_entries.clear()