# This file was created automatically from build script
__xvm_version__ = '8.4.0'
__wot_version__ = '1.8.0.1'
__revision__ = '0016'
__branch__ = 'master'
__node__ = 'e53872f7c3e03180493ce75f40212228fc22ce58'
__development__ = 'True'
