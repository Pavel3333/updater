# This file was created automatically from build script
__xvm_version__ = '8.2.4'
__wot_version__ = '1.7.0.2'
__revision__ = '32'
__branch__ = 'master'
__node__ = '2b8d4b3616bc7707b51fb9695e0468079de8afc2'
__development__ = 'True'
