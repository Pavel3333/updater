# This file was created automatically from build script
__xvm_version__ = '8.2.4'
__wot_version__ = '1.7.0.2'
__revision__ = '29'
__branch__ = 'master'
__node__ = '19f9e4f00e90b62c37475a86beb5902a72e0d747'
__development__ = 'True'
