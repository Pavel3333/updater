# This file was created automatically from build script
__xvm_version__ = '8.4.1'
__wot_version__ = '1.9.0.1'
__revision__ = '0025'
__branch__ = 'master'
__node__ = '68ba2cfc920c6022b373764d4008fb2ec49a9960'
__development__ = 'True'
