# This file was created automatically from build script
__xvm_version__ = '8.2.4'
__wot_version__ = '1.7.0.2'
__revision__ = '37'
__branch__ = 'master'
__node__ = '110abc467c7e8c5fa8bf311691669d6ee7e8d921'
__development__ = 'True'
