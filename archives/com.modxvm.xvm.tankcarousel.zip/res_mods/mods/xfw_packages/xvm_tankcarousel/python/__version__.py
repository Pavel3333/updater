# This file was created automatically from build script
__xvm_version__ = '8.2.4'
__wot_version__ = '1.7.0.2'
__revision__ = '43'
__branch__ = 'master'
__node__ = '385ed8320acd7a46ae1973a4321c6daae9e25ee2'
__development__ = 'True'
