# This file was created automatically from build script
__xvm_version__ = '8.2.4'
__wot_version__ = '1.7.0.2'
__revision__ = '41'
__branch__ = 'master'
__node__ = '23d6cff108e4d70f7d832e6bc635aca66136bdbd'
__development__ = 'True'
