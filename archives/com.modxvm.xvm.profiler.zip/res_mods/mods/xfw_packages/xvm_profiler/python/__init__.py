""" XVM (c) https://modxvm.com 2013-2019 """

from xfw import IS_DEVELOPMENT

if IS_DEVELOPMENT:
    import profiler
