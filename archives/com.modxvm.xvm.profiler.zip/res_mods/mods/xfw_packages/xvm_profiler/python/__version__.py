# This file was created automatically from build script
__xvm_version__ = '8.3.6'
__wot_version__ = '1.8.0.1'
__revision__ = '6'
__branch__ = 'master'
__node__ = '14a31241e2ce50a49cb27fb28b1e28e42e80f8fb'
__development__ = 'True'
