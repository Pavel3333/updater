# This file was created automatically from build script
__xvm_version__ = '8.3.2'
__wot_version__ = '1.7.1.2'
__revision__ = '1'
__branch__ = 'master'
__node__ = '0813006d1563e71ff6df760af57d6df22e779853'
__development__ = 'True'
